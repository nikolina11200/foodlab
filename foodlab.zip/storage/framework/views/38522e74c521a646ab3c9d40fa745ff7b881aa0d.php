<hr>

<p class="text-center">Copyright Nikolina Živković - All Rights Reserved</p>
        <?php /**PATH C:\Users\User\foodlab\resources\views/partials/_footer.blade.php ENDPATH**/ ?>