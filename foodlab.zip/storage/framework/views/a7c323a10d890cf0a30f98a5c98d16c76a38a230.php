<?php $titleTag = htmlspecialchars($post->title); ?>
<?php $__env->startSection('title', "| $titleTag"); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-4 col-md-offset-2">
            <img src="<?php echo e(asset('images/' . $post->image)); ?>" height="250" width="350" />
        </div>
        <div class="col-md-8 col-md-offset-2 shadow p-3 mb-5 bg-white rounded">
            <h2 class="card-title" style="display:inline-block;"><?php echo e($post->title); ?></h2>
            <p style="display:inline-block;font-style:italic;color:#aaa;">by <?php echo e($post->users['name']); ?></p>
            <p><?php echo $post->ingridients; ?></p>
            <hr>
            <p><?php echo $post->body; ?></p>
        </div>
    </div>

    <div class="row d-flex justify-content-center" style="margin-top:20px;">
        <div class="col-md-8 col-md-offset-2 shadow p-3 mb-5 bg-white rounded">
            <h3 class="comments-ttitle"><i class="fas fa-comment-dots"></i>
            <?php echo e($post->comments()->count()); ?> Comments</h3>
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comment">
                    <div class="author-info">
                        <img src="<?php echo e('https://www.gravatar.com/avatar/' . md5(strtolower(trim($comment->email))) . '?&d=robohash'); ?>" class="author-image">
                        <div class="author-name">
                            <h4><?php echo e($comment->name); ?></h4>
                            <p class="author-time"><?php echo e(date('F nS, Y - G:i' ,strtotime($comment->created_at))); ?></p>
                        </div>
                    </div>
                    <div class="comment-content">
                        <?php echo e($comment->comment); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php if(Auth::check()): ?>
    <div class="row d-flex justify-content-center">
        <div id="comment-form" class="col-md-8 col-md-offset-md-2">
        <form method="POST" action="<?php echo e(route('comments.store', $post->id)); ?>">
        <?php echo e(csrf_field()); ?>

            <div class="row">
            <div class="col-md-6">
                <label name="name">Name:</label>
                <input id="name" name="name"  maxlength='255' required class="form-control">
            </div>
            <div class="col-md-6">
                <label name="email">Email:</label>
                <input id="email" name="email"  maxlength='255' required class="form-control">
            </div>
            <div class="col-md-12">
                <label name="comment">Comment:</label>
                <textarea id="comment" name="comment" rows="5" class="form-control" required></textarea>
                <input type="submit" value="Add Comment" class="btn btn-info btn-block">
            </div>
            </div>
        </form>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/foodlab/single.blade.php ENDPATH**/ ?>