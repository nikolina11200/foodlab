<?php $__env->startSection('title', '| Foodlab'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <h1 style="text-align:center;" class="niceText">Recipes</h1>
        </div>
    </div>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
    <div class="col-md-12 col-md-offset-2">
    <div class="card flex-row flex-wrap shadow p-3 mb-5 rounded">
        <div class="col-sm-3">
		<div class="card border-0">
            <img src="<?php echo e(asset('images/' . $post->image)); ?>" height="200" width="200" class="img-thumbnail"/>
        </div>
                <p class="averageText">Average Rating:<?php echo e($post->averageRating()); ?></p>
        </div>
        <div class="col-sm-8">
		<div class="card-block px-2">
            <h2 class="card-title" style="display:inline-block;"><?php echo e($post->title); ?></h2>
            <p style="display:inline-block;font-style:italic;color:#aaa;">by <?php echo e($post->users['name']); ?></p>
            <p class="card-text"><?php echo $post->ingridients; ?></p>
            <hr>
            <p class="card-text"><?php echo e(substr(strip_tags($post->body), 0, 250)); ?><?php echo e(strlen(strip_tags($post->body)) > 250 ? '...' : ""); ?></p>

            <a href="<?php echo e(route('foodlab.single', $post->slug)); ?>" class="btn btn-info">Read More</a>
        </div>
        </div>
        <div class="card-footer w-100 text-muted ">
            <h6 style="float:right;">Published: <?php echo e(date('M j, Y', strtotime($post->created_at))); ?></h6>
        </div>
        </div>
        </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="row">
        <div class="col-md-12" >
            <div class="d-flex justify-content-center">
                <?php echo $posts->links(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/foodlab/index.blade.php ENDPATH**/ ?>