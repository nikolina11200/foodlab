<?php $__env->startSection('title', '| All Users'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-10">
            <h1 class="niceText">All Users</h1>
        </div>
        <div class="col-md-2">
            <a href="<?php echo e(route('admin_users.create')); ?>" class="btn btn-lg btn-block btn-info btn-h1-spacing">Create New User</a>        
        </div>
        <div class="col-md-12">
            <hr>
        </div>
    </div> <!--end of row-->

    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>isAdmin</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Created At</th>
                </thead>

                <tbody>
                
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->isAdmin); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->password); ?></td>
                            <td><?php echo e(date('M j, Y h:ia', strtotime($user->created_at))); ?></td>
                            <td><a href="<?php echo e(route('admin_users.show', $user->id)); ?>" class="btn btn-info btn-sm">View</a> 
                            <a href="<?php echo e(route('admin_users.edit', $user->id)); ?>" class="btn btn-danger btn-sm">Edit</a></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo $users->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_users/index.blade.php ENDPATH**/ ?>