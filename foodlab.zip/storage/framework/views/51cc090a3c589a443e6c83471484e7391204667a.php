<nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background-color:  #d9ce95;">
        <img width="100px" src="/foodlablogo.png">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
            <li class="<?php echo e(Request::is('/') ? "active" : ""); ?>">
                <a class="nav-link" href="/">HOME <span class="sr-only" style="font-family: Quicksand;">(current)</span></a>
            </li>
            <li class="<?php echo e(Request::is('foodlab') ? "active" : ""); ?>">
                <a class="nav-link" href="/foodlab">FOODLAB <span class="sr-only" style="font-family: Quicksand;">(current)</span></a>
            </li>
            <li class="<?php echo e(Request::is('about') ? "active" : ""); ?>">
                <a class="nav-link" href="/about" style="font-family: Quicksand;">ABOUT</a>
            </li>
            <li class="<?php echo e(Request::is('contact') ? "active" : ""); ?>">
                <a class="nav-link" href="/contact" style="font-family: Quicksand;">CONTACT</a>
            </li>
            </ul>
            
            <ul class="nav navbar-nav navbar-right">
            <?php if(Auth::check()): ?>
            <?php if(auth()->user()->isAdmin == 1): ?>
            <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('admin_posts.create')); ?>" class="btn btn-warning btn-block">
        <i class="fas fa-utensils fa-2x"></i>
        </a>
        <?php else: ?> 
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('posts.create')); ?>" class="btn btn-warning btn-block">
        <i class="fas fa-utensils fa-2x"></i>
        </a>
        <?php endif; ?>
            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hello <?php echo e(Auth::user()->name); ?>

        </a>
        <ul class="dropdown-menu">
        <?php if(auth()->user()->isAdmin == 1): ?>
          <li><a class="dropdown-item" href="<?php echo e(route('admin_posts.index')); ?>">Recipes</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin_ratings.index')); ?>">Ratings</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin_comments.index')); ?>">Comments</a></li>
          <li><a class="dropdown-item" href="<?php echo e(route('admin_users.index')); ?>">Users</a></li>
          <hr>
          <?php else: ?>
          <li><a class="dropdown-item" href="<?php echo e(route('posts.index')); ?>">Recipes</a></li>
          <hr>
          <?php endif; ?>
          <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                
                </li>
        </ul>
        </li>
        <?php else: ?>

          <a href="<?php echo e(route('login')); ?>" class="btn btn-default" style="font-family: 'Quicksand';">LOGIN</a>
          <a href="<?php echo e(route('register')); ?>" class="btn btn-default" style="font-family: 'Quicksand';">REGISTER</a>
        <?php endif; ?>

      </ul>
        </div>
        </nav>
        <br>
        <br>
        <br>
        <?php /**PATH C:\xampp\htdocs\foodlab\resources\views/partials/_nav.blade.php ENDPATH**/ ?>