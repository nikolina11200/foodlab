      
      <?php $__env->startSection('title', '| About'); ?>
      <?php $__env->startSection('content'); ?>      
            <div class="row d-flex justify-content-center">
                <div class="col-md-8 shadow p-3 mb-5 bg-white rounded" >
                    <h1 class="niceText">About Me</h1>
                    <hr>
                    <p>My name is Nikolina Živković, I'm 22 year old student living in Kostrč in Bosnia and Herzegowina.<br>
                After finishing high school i started my college journey here in small town Orašje.<br>In 2016. I applied to the Faculty of Informatics FPMOZ.
                <br> At the beginning of the third year started a project in the subject Programming for Internet, which later became my final thesis. <br>
                This project is done in the laravel framework and is designed for everyone to share recipes around the world.<br><br><br> 
                Good luck writing recipes! </p>
                </div>
            </div>  
        <?php $__env->stopSection(); ?>      
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/pages/about.blade.php ENDPATH**/ ?>