<?php $__env->startSection('title', '| Edit Comment'); ?>

<?php $__env->startSection('content'); ?>
<div class="row d-flex justify-content-center">
    <div class="col-md-8 col-md-offset-2">
    <h1 class="niceText">Edit Comment</h1>

    <form method="POST" action="<?php echo e(route('comments.update', $comment->id)); ?>">
<?php echo e(method_field('PUT')); ?>

<?php echo e(csrf_field()); ?>

                    <label name="name">Name:</label>
                    <input id="name" name="name"  maxlength='255' required class="form-control" value="<?php echo e(old('name', $comment->name)); ?>" disabled>

                    <label name="email">Email:</label>
                    <input id="email" name="email" minlength='5' maxlength='255' required class="form-control" value="<?php echo e(old('email', $comment->email)); ?>" disabled>
                    
                    <label name="comment">Comment:</label>
                    <textarea id="comment" name="comment" rows="10"  required class="form-control"><?php echo e(old('comment', $comment->comment)); ?></textarea>
                    <input type="submit" value="Update comment" class="btn btn-info btn-block" style="margin-top:15px;">
	</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/comments/edit.blade.php ENDPATH**/ ?>