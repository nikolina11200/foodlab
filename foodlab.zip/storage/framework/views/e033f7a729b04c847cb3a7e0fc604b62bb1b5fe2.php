<?php $__env->startSection('content'); ?>

<div class="container">

<?php if(\Session::has('error')): ?>

<div class="alert alert-danger">

<?php echo e(\Session::get('error')); ?>


</div>

<?php endif; ?>
<br><br><br>
<div class="row">
    <div class="col-md-12 col-md-offset-2 shadow p-3 mb-5 bg-white rounded">
    <div class="panel panel-default">
        <div class="panel-heading" ><h1 class="niceText" style="text-align:center;">Choose user role!</h1></div>
        <div class="row">
        <div class="col-md-6">
    <div class="panel-body">
        <a href="<?php echo e(url('admin/routes')); ?>" class="btn btn-danger btn-block">Admin</a>
    </div>
        </div>
        <div class="col-md-6">
        <a href="<?php echo e(url('/')); ?>" class="btn btn-info btn-block">Normal user</a>
        </div>
        </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/home.blade.php ENDPATH**/ ?>