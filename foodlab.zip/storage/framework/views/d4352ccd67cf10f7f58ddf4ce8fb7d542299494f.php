<?php $__env->startSection('title', '| Create new user'); ?>

<?php $__env->startSection('stylesheets'); ?>

    <link rel='stylesheet' href='/css/parsley.css' />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row d-flex justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <h1 class="niceText">Create new user</h1>
            <hr>
            <form  data-parsley-validate method="POST" action="<?php echo e(route('admin_users.store')); ?>">
                <div class="form-group">
                    <label name="isAdmin">isAdmin:</label>
                    <input id="isAdmin" name="isAdmin" class="form-control" maxlength='1'>
                </div>
                <div class="form-group">
                    <label name="name">Name:</label>
                    <input id="name" name="name" class="form-control" maxlength='255' required>
                </div>
                <div class="form-group">
                    <label name="email">Email:</label>
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                </div>
                <div class="form-group">
                    <label name="password">Password:</label>
                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                </div>
                <div class="form-group">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm Password:</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                </div>
                <input type="submit" value="Create User" class="btn btn-success btn-lg btn-block">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/parsley.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_users/create.blade.php ENDPATH**/ ?>