<hr>

<p class="text-center">Copyright Nikolina Živković - All Rights Reserved</p>
        <?php /**PATH C:\xampp\htdocs\foodlab\resources\views/partials/_footer.blade.php ENDPATH**/ ?>