<h3>You have a New Contact Via Contact Form</h3>

<div>
    <?php echo e($bodyMessage); ?>

</div>

<p>Sent via <?php echo e($email); ?></p><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/emails/contact.blade.php ENDPATH**/ ?>