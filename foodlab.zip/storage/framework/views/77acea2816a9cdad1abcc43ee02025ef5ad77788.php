<?php $__env->startSection('title', '| Edit User'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('admin_users.update', $user->id)); ?>">
<?php echo e(method_field('PUT')); ?>

<?php echo e(csrf_field()); ?>

		<div class="row">
        <div class="col-md-8 mb-3">
                
                    <label name="isAdmin">isAdmin:</label>
                    <input id="isAdmin" name="isAdmin"  maxlength='1' class="form-control" value="<?php echo e(old('isAdmin', $user->isAdmin)); ?>">

                    <label name="name">Name:</label>
                    <input id="name" name="name"  maxlength='255' required class="form-control" value="<?php echo e(old('name', $user->name)); ?>">

                    <label name="email">Email:</label>
                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="email" autofocus>
                
                    <label name="password">Password:</label>
                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="<?php echo e(old('password', $user->password)); ?>" required autocomplete="current-password">
                
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
			<div class="card-body">
                <dl class="dl-horizontal">
                    <dt>Created At:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($user->created_at))); ?></dd>
                </dl>

                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($user->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <a href="<?php echo e(route('admin_users.show', $user->id)); ?>" class="btn btn-danger btn-block">Cancel</a>
                    </div>
                    <div class="col-sm-6">
                    <input type="submit" value="Save Changes" class="btn btn-success btn-block">
                    </div>
                </div>
			</div>
            </div>
        </div>
    </div>
	</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_users/edit.blade.php ENDPATH**/ ?>