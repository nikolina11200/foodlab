<?php $__env->startSection('title', '| All Recipes'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-10">
            <h1 class="niceText">All Recipes</h1>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
    </div> <!--end of row-->

    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Title</th>
                    <th>Preparation</th>
                    <th>Body</th>
                    <th>Image</th>
                    <th>Created At</th>
                </thead>

                <tbody>
                
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th><?php echo e($post->id); ?></th>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo $post->ingridients; ?></td>
                            <td><?php echo e(substr(strip_tags($post->body), 0, 50)); ?><?php echo e(strlen(strip_tags($post->body)) > 50 ? "..." : ""); ?></td>
                            <td><img src="<?php echo e(asset('images/' . $post->image)); ?>" height="200" width="200" /></td>
                            <td><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></td>
                            <td><a href="<?php echo e(route('admin_posts.show', $post->id)); ?>" class="btn btn-info btn-sm">View</a> 
                            <a href="<?php echo e(route('admin_posts.edit', $post->id)); ?>" class="btn btn-danger btn-sm">Edit</a></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo $posts->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_posts/index.blade.php ENDPATH**/ ?>