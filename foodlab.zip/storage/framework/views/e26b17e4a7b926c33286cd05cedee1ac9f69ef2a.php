<?php $__env->startSection('title', '| All Ratings'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-10">
            <h1 class="niceText">All Ratings</h1>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
    </div> <!--end of row-->

    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Created_at</th>
                    <th>Rating</th>
                    <th>Rateable_id</th>
                    <th>User_id</th>
                    <th></th>
                </thead>

                <tbody>
                
                    <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th><?php echo e($rating->id); ?></th>
                            <td><?php echo e(date('M j, Y h:ia', strtotime($rating->created_at))); ?></td>
                            <td><?php echo e($rating->rating); ?></td>
                            <td><?php echo e($rating->rateable_id); ?></td>
                            <td><?php echo e($rating->user_id); ?></td>
                            <td><form  method="POST" action="<?php echo e(route('admin_ratings.destroy', $rating->rateable_id)); ?>">
                            <input type="submit" value="Delete" class="btn btn-danger btn-block">
                            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            <?php echo e(method_field('DELETE')); ?>

                        </form></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo $ratings->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_ratings/index.blade.php ENDPATH**/ ?>