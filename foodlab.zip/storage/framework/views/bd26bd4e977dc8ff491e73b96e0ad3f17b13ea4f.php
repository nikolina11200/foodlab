<?php $__env->startSection('title', '| DELETE COMMENT?'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center">
        <div class="col-md-8 col-md-offset-2 shadow p-3 mb-5 bg-white rounded">
            <h1>DELETE THIS COMMENT?</h1>
            <p>
                <strong>Name:</strong> <?php echo e($comment->name); ?><br>
                <strong>Email:</strong> <?php echo e($comment->email); ?><br>
                <strong>Comment:</strong> <?php echo e($comment->comment); ?><br>
            </p>
            <form method="POST" action="<?php echo e(route('comments.destroy', $comment->id)); ?>">    
                <input type="submit" value="YES, delete this comment" class="btn btn-danger btn-lg btn-block">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <?php echo e(method_field('DELETE')); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/comments/delete.blade.php ENDPATH**/ ?>