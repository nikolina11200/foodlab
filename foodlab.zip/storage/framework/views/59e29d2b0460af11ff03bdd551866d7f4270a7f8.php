<?php $__env->startSection('title', '| Homepage'); ?>
       <?php $__env->startSection('content'); ?> 
            <div class="row">
                <div class="col-md-12">
                <div class="jumbotron">
                    <h1 class="display-4">Welcome to FoodLab</h1>
                    <p class="lead">Thank you for visiting my FoodLab page</p>
                    <a class="btn btn-primary btn-lg" href="#" role="button">Popular post</a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="post">
                        <h3>Post title</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                    <hr>
                    <div class="post">
                        <h3>Post title</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                    <hr>
                    <div class="post">
                        <h3>Post title</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                    <hr>
                    <div class="post">
                        <h3>Post title</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                </div>

                <div class="col-md-3 col-md-offset-1">
                    <h2>Sidebar</h2>
                </div>
            </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\foodlab\resources\views/pages/welcome.blade.php ENDPATH**/ ?>