<?php $__env->startSection('title', '| Edit Recipe'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('posts.update', $post->id)); ?>">
<?php echo e(method_field('PUT')); ?>

<?php echo e(csrf_field()); ?>

		<div class="row">
        <div class="col-md-8 mb-3">
                
                    <label name="title">Title:</label>
                    <input id="title" name="title"  maxlength='255' required class="form-control" value="<?php echo e(old('title', $post->title)); ?>">

                    <label name="slug">Slug:</label>
                    <input id="slug" name="slug" minlength='5' maxlength='255' required class="form-control" value="<?php echo e(old('slug', $post->slug)); ?>">

                    <label name="ingridients">Ingridients:</label>
                    <textarea id="ingridients" name="ingridients" rows="10"  required class="form-control"><?php echo e(old('ingridients', $post->ingridients)); ?></textarea>
                
                
                    <label name="body">Post Body:</label>
                    <textarea id="body" name="body" rows="10" required class="form-control"><?php echo e(old('body', $post->body)); ?></textarea>
                
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
			<div class="card-body">
                <dl class="dl-horizontal">
                    <dt>Created At:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></dd>
                </dl>

                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($post->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-danger btn-block">Cancel</a>
                    </div>
                    <div class="col-sm-6">
                    <input type="submit" value="Save Changes" class="btn btn-success btn-block">
                    </div>
                </div>
			</div>
            </div>
        </div>
    </div>
	</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/posts/edit.blade.php ENDPATH**/ ?>