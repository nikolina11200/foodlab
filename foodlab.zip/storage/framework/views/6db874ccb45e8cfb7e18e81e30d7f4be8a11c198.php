<?php $__env->startSection('title', '| Create new recipe'); ?>

<?php $__env->startSection('stylesheets'); ?>

    <link rel='stylesheet' href='/css/parsley.css' />
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script>
    tinymce.init({
        selector:'textarea',
        plugins:'lists',
        toolbar: 'numlist bullist'
    });
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row d-flex justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <h1 class="niceText">Create new recipe</h1>
            <hr>
            <form  data-parsley-validate method="POST" action="<?php echo e(route('posts.store')); ?>" enctype="multipart/form-data">
                <div class="form-group">
                    <label name="title">Title:</label>
                    <input id="title" name="title" class="form-control" maxlength='255' required>
                </div>
                <div class="form-group">
                    <label name="slug">Slug:</label>
                    <input id="slug" name="slug" class="form-control" minlength='5' maxlength='255' required>
                </div>
                <div class="form-group">
                    <label name="featured_image">Upload your image:</label>
                    <input id="featured_image" name="featured_image" rows="10" type="file">
                </div>
                <div class="form-group">
                    <label name="ingridients">Ingridients:</label>
                    <textarea id="ingridients" name="ingridients" rows="10" class="form-control" required></textarea>
                </div>
                <div class="form-group">
                    <label name="body">Preparation:</label>
                    <textarea id="body" name="body" rows="10" class="form-control" required></textarea>
                </div>
                <input type="submit" value="Create Recipe" class="btn btn-info btn-lg btn-block">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/parsley.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/posts/create.blade.php ENDPATH**/ ?>