<?php $__env->startSection('title', '| View Rating'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <h1><?php echo e($rating->rating); ?></h1>
            <p class="lead"><?php echo e($rating->rateable_id); ?></p>
            <p class="lead"><?php echo e($rating->user_id); ?></p>
        </div>
        <div class="col-md-4">
            <div class="card">
            <div class="card-body">
                <dl class="dl-horizontal">
                    <dt>Created At:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($rating->created_at))); ?></dd>
                </dl>

                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($rating->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <form  method="POST" action="<?php echo e(route('admin_ratings.destroy', $rating->rateable_id)); ?>">
                            <input type="submit" value="Delete" class="btn btn-danger btn-block">
                            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            <?php echo e(method_field('DELETE')); ?>

                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                    <br>
                    <a href="<?php echo e(route('admin_ratings.index')); ?>" class="btn btn-default btn-block">Show all Ratings</a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_ratings/show.blade.php ENDPATH**/ ?>