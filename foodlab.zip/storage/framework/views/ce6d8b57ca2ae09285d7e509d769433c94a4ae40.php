<?php $__env->startSection('title', '| All Comments'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-10">
            <h1 class="niceText">All Comments</h1>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
    </div> <!--end of row-->

    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Comment</th>
                    <th>Post_id</th>
                    <th>Created At</th>
                </thead>

                <tbody>
                
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th><?php echo e($comment->id); ?></th>
                            <td><?php echo e($comment->name); ?></td>
                            <td><?php echo e($comment->email); ?></td>
                            <td><?php echo e($comment->comment); ?></td>
                            <td><?php echo e($comment->post_id); ?></td>
                            <td><?php echo e(date('M j, Y h:ia', strtotime($comment->created_at))); ?></td>
                            <td><form  method="POST" action="<?php echo e(route('admin_comments.destroy', $comment->post_id)); ?>">
                            <input type="submit" value="Delete" class="btn btn-danger btn-block">
                            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            <?php echo e(method_field('DELETE')); ?>

                        </form>
                        <a href="<?php echo e(route('comments.edit', $comment->id)); ?>" class="btn btn-block btn-info">Edit</a>
                    </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo $comments->links();; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/comments/index.blade.php ENDPATH**/ ?>