<?php $__env->startSection('title', '| View User'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8 shadow p-3 mb-5 bg-white rounded">
            <h1><?php echo e($user->name); ?></h1>
            <p class="lead"><?php echo e($user->email); ?></p>
            <p class="lead"><?php echo e($user->password); ?></p>
        </div>
        <div class="col-md-4">
            <div class="card">
            <div class="card-body">
                <dl class="dl-horizontal">
                    <dt>Created At:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($user->created_at))); ?></dd>
                </dl>

                <dl class="dl-horizontal">
                    <dt>Last Updated:</dt>
                    <dd><?php echo e(date('M j, Y h:ia', strtotime($user->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <a href="<?php echo e(route('admin_users.edit', $user->id)); ?>" class="btn btn-info btn-block">Edit</a>
                    </div>
                    <div class="col-sm-6">
                        <form  method="POST" action="<?php echo e(route('admin_users.destroy', $user->id)); ?>">
                            <input type="submit" value="Delete" class="btn btn-danger btn-block">
                            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                            <?php echo e(method_field('DELETE')); ?>

                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                    <br>
                    <a href="<?php echo e(route('admin_users.index')); ?>" class="btn btn-default btn-block"><strong>Show all Users</strong></a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodlab\resources\views/admin_users/show.blade.php ENDPATH**/ ?>