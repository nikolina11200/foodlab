<h3>You have a New Contact Via Contact Form</h3>

<div>
    {{ $bodyMessage }}
</div>

<p>Sent via {{ $email }}</p>